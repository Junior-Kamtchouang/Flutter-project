import 'package:flutter/material.dart';
import 'dart:io';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.purple[900],
          title: Center(
              child: Text('Ebawed')
          ),
        ),
        body: WebView(
          initialUrl: 'https://ebawed.com/',//url from the converted website
          javascriptMode: JavascriptMode.unrestricted,
        ),
      ),
    );
  }
}

